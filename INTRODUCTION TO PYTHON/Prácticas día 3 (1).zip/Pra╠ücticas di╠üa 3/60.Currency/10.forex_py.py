# usd2eur.py
# juanfc 2019-11-19
# pip3 install forex-python
# https://forex-python.readthedocs.io/en/latest/index.html

from forex_python.converter import CurrencyRates
c = CurrencyRates()
u2e = c.get_rate('USD', 'EUR')


nDolares = 10
print(nDolares, "$ ->", nDolares * u2e, "€")
nEuros = 10
print(nEuros, "€ ->", nEuros/u2e, "$")
