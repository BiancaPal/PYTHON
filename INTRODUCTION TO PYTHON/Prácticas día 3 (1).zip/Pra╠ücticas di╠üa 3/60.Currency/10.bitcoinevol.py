# 10.bitcoinevol.py
# juanfc 2019-11-19
import datetime
import numpy as np
import matplotlib.pyplot as plt
from forex_python.bitcoin import BtcConverter

b = BtcConverter()

star_date = datetime.datetime(2011, 1, 1)
end_date  = datetime.datetime(2019, 11, 20)
# np.arange("2018-01-01", "2019-11-20", dtype="datetime64")

bcList = b.get_previous_price_list('EUR', star_date, end_date)

nueva = {}
for dia in bcList:
    if dia.endswith('-01'):
        nueva[dia] = bcList[dia]



lists = list(nueva.items())
x, y = zip(*lists)

fig = plt.figure()



plt.title("BitCoin evolution from %s" % star_date)
plt.xlabel("Date")
plt.ylabel("€")

plt.xticks(rotation=-90)
plt.autoscale(tight=True)
plt.grid()


plt.plot(x, y)
plt.show()
