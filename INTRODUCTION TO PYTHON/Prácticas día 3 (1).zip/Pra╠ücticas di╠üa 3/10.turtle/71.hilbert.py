# 71.hilbert.py
# juanfc 2019-10-16

from turtle import *

def hilbert_curve(n, angle=90):
    if n <= 0:
        return

    left(angle)
    hilbert_curve(n - 1, -angle)
    forward(1)
    right(angle)
    hilbert_curve(n - 1, angle)
    forward(1)
    hilbert_curve(n - 1, angle)
    right(angle)
    forward(1)
    hilbert_curve(n - 1, -angle)
    left(angle)

depth = 4
size = 2 ** depth

screen = Screen()
screen.setworldcoordinates(0, 0, size, size)

speed('fastest')
penup()
goto(0.5, 0.5)
pendown()

hideturtle()
hilbert_curve(depth)


done()



