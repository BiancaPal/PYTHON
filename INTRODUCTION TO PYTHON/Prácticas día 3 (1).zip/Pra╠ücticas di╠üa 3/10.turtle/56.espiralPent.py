# espiralPenpy
# juanfc 2019-10-08

from turtle import *
speed(8) # 1 slow, 10 max speed. 0 top speed

lado = 200
ang = 360/6
Screen().colormode(255)

for i in range(100):
    forward(lado)
    right(ang) # el ángulo exterior del pentágono
    pencolor(i, i, i)
    lado = lado - 2

done()