# 55.chessboard.py
# juanfc 2020-11-07
# https://gist.github.com/0bfa3ca9ef46b85cdba9585395d271ff

from turtle import *

ancho = 50

speed(0)
color("black", "black")

penup()
goto(-4*ancho, -4*ancho)

for fila in range(8):

    for i in range(4):
        pendown()
        begin_fill()
        for i in range(4):
            fd(ancho)
            left(90)
        end_fill()
        penup()

        setx(xcor()+ancho*2)



    if fila % 2 == 0:
        setx(-4*ancho+ancho)
    else:
        setx(-4*ancho)

    sety(ycor()+ancho)

penup()
goto(-4*ancho, -4*ancho)
setheading(0)
pendown()
for i in range(4):
    fd(ancho*8)
    left(90)


done()