# 70.sierpinski.py
# juanfc 2019-10-16

from turtle import *
def draw_sierpinski(length, depth):
    if depth == 0:
        for i in range(0, 3):
            fd(length)
            left(120)
    else:
        draw_sierpinski(length/2, depth-1)
        fd(length/2)
        draw_sierpinski(length/2, depth-1)
        bk(length/2)
        left(60)
        fd(length/2)
        right(60)
        draw_sierpinski(length/2, depth-1)
        left(60)
        bk(length/2)
        right(60)

# ht()
speed(0) # 1 slow, 10 max speed. 0 top speed
pu()
goto(-300, -300)
pd()
draw_sierpinski(600,4)
done()


