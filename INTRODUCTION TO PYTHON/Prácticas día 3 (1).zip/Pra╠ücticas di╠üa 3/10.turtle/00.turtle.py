# 00.turtle.py
# juanfc 2019-10-03

from turtle import *


# la movemos hacia adelante
forward(150)
# izquierda (en grados)
left(90)
forward(75)

done()