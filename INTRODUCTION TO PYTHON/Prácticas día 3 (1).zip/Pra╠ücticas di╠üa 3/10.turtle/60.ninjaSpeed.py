# espiralPoli.py
# juanfc 2019-10-08

from turtle import *

speed(0) # 1 slow, 10 max speed. 0 top speed

for i in range(180):
    forward(100)
    right(30)
    forward(20)
    left(60)
    forward(50)
    right(30)

    penup()
    setposition(0, 0)
    pendown()

    right(2)

done()
