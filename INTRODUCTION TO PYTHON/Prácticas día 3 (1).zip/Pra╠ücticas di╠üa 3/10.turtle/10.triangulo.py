# 10.triangulo.py
# juanfc 2019-10-08

# Pedir los catetos de un triángulo rectángulo e imprimirlos y calcular
# e imprimir su hipotenusa


import math
from turtle import *

a = 100 #float(input("Entrar base: "))
b = 200 # float(input("Entrar altura: "))


wn = Screen()
wn.bgcolor("lightgreen")


forward(a)
left(180)
forward(a)
left(-90)
forward(b)


done()
