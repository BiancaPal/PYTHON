# 08.casaSinLevantar.py
# juanfc 2019-11-06
#
from turtle import *

goto(-200, 200 ) # 1
goto(-200, 0   ) # 2
goto(0,    200 ) # 3
goto(-100,  300 ) # 4
goto(-200, 200 ) # 5
goto(0,    200 ) # 6
goto(0,    0   ) # 7
goto(-200, 0   ) # 8


done()
