# 58.randomturtle.py
# juanfc 2019-10-21


import turtle               # allows us to use the turtles library
import random

pasos = 100 # int(input('Introduzca número de pasos: '))

wn = turtle.Screen()        # creates a graphics window
MAX_COLOR = 254
wn.colormode(MAX_COLOR+1)
t = turtle.Turtle()
t.speed(0)

for indice in range(pasos):
    angulo = random.randint(-90, 90)
    colorr = random.randint(0, MAX_COLOR)
    colorg = random.randint(0, MAX_COLOR)
    colorb = random.randint(0, MAX_COLOR)
    avance = random.randint(1, 50)
    ancho  = random.randint(1, 5)
    t.pensize(ancho)
    t.forward(avance)
    t.pencolor(colorr, colorg, colorb)
    t.left(angulo)

turtle.done()
