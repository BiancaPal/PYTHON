#Program to draw circle in Python Turtle
from turtle import *

PI = 3.1416
radio = 100 # float(input('Introduzca el radio de la circunferencia: ').replace(',','.'))



up()
goto(0, -radio)
down()
fillcolor('red')
begin_fill()
circle(radio)
end_fill()

up()
goto(0, 0)
pencolor('blue')
write('Radio: ' + str(radio))
goto(0, -10)
write('Area: ' + str(PI*radio**2))

done()
