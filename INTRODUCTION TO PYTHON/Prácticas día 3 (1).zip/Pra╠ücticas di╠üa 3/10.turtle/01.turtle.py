# 01.turtle.py
# juanfc 2019-10-03

from turtle import *

wn = Screen()
wn.bgcolor("lightgreen")

forward(150)
left(90)
forward(75)

done()

