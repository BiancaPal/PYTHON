# espiralPoli.py
# juanfc 2019-10-08

import turtle
wn = turtle.Screen()
t = turtle.Turtle()

numLados = 12 # = int(input('¿Número de lados: '))
lado = 100
exteriorAngle = 360/numLados

for i in range(200):
   t.forward(lado)
   t.right(exteriorAngle)
   lado = lado - 0.5

wn.exitonclick()