# poligono.py
# juanfc 2019-10-08

from turtle import *

PI = 3.1416
radio = 100 # float(input('Introduzca el radio de la circunferencia: ').replace(',','.'))

numLados = 16 # = int(input('¿Número de lados: '))
longLado = 50 # = int(input('¿Longitud del lado: '))
angExt = 360/numLados

for i in range(numLados):
   forward(longLado)
   right(angExt)

done()