# 11.estrella.py
# juanfc 2019-10-08

# 11.estrella.py
# juanfc 2019-10-08

from turtle import *

n = 14
for i in range(n):
    forward(50)
    right(360/n)

done()


