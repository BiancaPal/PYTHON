# 90.calculadora.py
# juanfc

from tkinter import *
import math

NOVALMSG = 'Entrada no valida'

def equals(nada=""):
    try:
        return sustituyePor(eval(e.get()))
    except SyntaxError or NameErrror:
        error()

def elevadoA(p):
    v = equals()
    if v: sustituyePor(v**p)

def error():
    limpia()
    e.insert(0,NOVALMSG)

def limpia():
    e.delete(0,END)

def borraUlt():
    e.delete(len(e.get())-1,END)

def sustituyePor(v):
    limpia()
    e.insert(0,v)
    return v

def montaBotón(txt, row, col):
    def addtxt(txt):
        if e.get() == NOVALMSG:
            limpia()
        e.insert(END,txt)
    Button(raiz,text=txt,width=3,command=lambda:addtxt(txt)). grid(row=row, column=col)

# Montándolo todo
raiz = Tk()
raiz.title('Calculadora')
raiz.eval('tk::PlaceWindow . center')
raiz.bind("<Return>", equals)


e = Entry(raiz, bg='gray',width=35)
e.grid(row=0,column=0,columnspan=8,pady=3)
e.focus_set()

# Construyendo los botones
Button(raiz,text="=",width=10,command=lambda:equals()).     grid(row=4, column=4,columnspan=2)
Button(raiz,text='AC',width=3,command=lambda:limpia()).     grid(row=1, column=4)
Button(raiz,text='C', width=3,command=lambda:borraUlt()).   grid(row=1, column=5)
Button(raiz,text="√", width=3,command=lambda:elevadoA(0.5)).grid(row=3, column=4)
Button(raiz,text="x²",width=3,command=lambda:elevadoA(2)).  grid(row=3, column=5)

montaBotón('+', 4, 3)
montaBotón('*', 2, 3)
montaBotón('-', 3, 3)
montaBotón('/', 1, 3)
montaBotón('%', 4, 2)
montaBotón('7', 1, 0)
montaBotón('8', 1, 1)
montaBotón('9', 1, 2)
montaBotón('4', 2, 0)
montaBotón('5', 2, 1)
montaBotón('6', 2, 2)
montaBotón('1', 3, 0)
montaBotón('2', 3, 1)
montaBotón('3', 3, 2)
montaBotón('0', 4, 0)
montaBotón('.', 4, 1)
montaBotón('(', 2, 4)
montaBotón(')', 2, 5)

raiz.mainloop()
