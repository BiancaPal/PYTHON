# 20.canvas.py
# juanfc
from tkinter import *

vent = Tk()
vent.geometry("200x200")
vent.eval('tk::PlaceWindow . center')

c = Canvas(vent, bg = "pink", height = "200", width = 200)

arc = c.create_arc((5,10,150,200),start = 0,extent = 150, fill= "blue")

c.pack()

vent.mainloop()


