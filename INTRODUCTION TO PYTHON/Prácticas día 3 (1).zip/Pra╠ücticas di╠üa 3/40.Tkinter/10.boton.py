# 00.ventanaSimple.py
# juanfc
# https://www.javatpoint.com/python-tkinter
# https://likegeeks.com/es/ejemplos-de-la-gui-de-python/


from tkinter import *

def pulsado():
    lbl.configure(text="¡El botón ha sido pulsado!")


window = Tk()
window.title("Bienvenidos a tkinter")
window.geometry('650x200')
lbl = Label(window, text="Hello", font=("Arial Bold", 48))
lbl.grid(column=0, row=0)
btn = Button(window, text="Púlsame", command=pulsado)
btn.grid(column=0, row=1)
window.mainloop()

import tkinter as tk
master = tk.Tk()
whatever_you_do = "Whatever you do will be insignificant, but it is very important that you do it.\n(Mahatma Gandhi)"
msg = tk.Message(master, text = whatever_you_do)
msg.config(bg='lightgreen', font=('times', 24, 'italic'))
msg.pack()
tk.mainloop()