# 33.menubar.py
# juanfc 2019-11-21
# https://likegeeks.com/python-gui-examples-tkinter-tutorial

from tkinter import *
from tkinter import Menu, messagebox

vent = Tk()
vent.title("Ventana y menús")

def acción(nada=""):
    messagebox.showinfo("Mensaje", 'Has seleccionado una acción de menú')

menu = Menu(vent)
nuevoItem = Menu(menu)
menu.add_cascade(label='Fichero', menu=nuevoItem)
nuevoItem.add_command(label='Nuevo', command=acción, accelerator='Command-N')
nuevoItem.add_separator()
nuevoItem.add_command(label='Salir', command=vent.destroy)
vent.config(menu=menu)

vent.mainloop()


