# 05.etiqueta.py
# juanfc
# https://www.python-course.eu/tkinter_message_widget.php

from  tkinter import *


contador = 0
def contador_etiq(etiq):
  def count():
    global contador
    contador += 1
    etiq.config(text=str(contador))
    etiq.after(1000, count)
  count()

ventana = Tk()
ventana.eval('tk::PlaceWindow . center')
ventana.title("Contando segundos")


etiqueta = Label(ventana, text="", font=("Arial Bold", 36))
etiqueta.pack()

msg = Message(ventana, text="Lo siguiente es un botón que destruye la ventana", font=("Times", 24))
msg.config(bg='gray', font=('helvetica', 24))
msg.pack()


contador_etiq(etiqueta)
Button(ventana, text='Parar', width=50, command=ventana.destroy).pack()

ventana.mainloop()

