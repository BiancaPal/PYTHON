# 03.messagebox.py
# juanfc 2019-11-21

from tkinter import messagebox

res = messagebox.showinfo('Messagebox tipo showinfo','Contenido del messagebox')
res = messagebox.askquestion('Messagebox tipo askquestion','Contenido del messagebox')
res = messagebox.askyesno('Messagebox tipo askyesno','Contenido del messagebox')
res = messagebox.askyesnocancel('Messagebox tipo askyesnocancel','Contenido del messagebox')
res = messagebox.askokcancel('Messagebox tipo askokcancel','Contenido del messagebox')
res = messagebox.askretrycancel('Messagebox tipo askretrycancel','Contenido del messagebox')

