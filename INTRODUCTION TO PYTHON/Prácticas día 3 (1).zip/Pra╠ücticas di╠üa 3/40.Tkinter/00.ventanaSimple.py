# 00.ventanaSimple.py
# juanfc


from tkinter import *

ventana = Tk()
ventana.mainloop()

