# 04.filedialog.py
# juanfc 2019-11-21

from tkinter import messagebox, filedialog
import os
from os import path

messagebox.showinfo('Selecciona un fichero en', os.getcwd())
file = filedialog.askopenfilename(initialdir= os.getcwd())

messagebox.showinfo('Has seleccionado el siguiente fichero', file)


