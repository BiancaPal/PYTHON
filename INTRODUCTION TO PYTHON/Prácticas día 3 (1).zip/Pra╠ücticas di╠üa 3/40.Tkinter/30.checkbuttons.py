# 30.checkbuttons.py
# juanfc
from tkinter import *

raiz = Tk()

raiz.geometry("200x200")
raiz.eval('tk::PlaceWindow . center')

checkvar1 = IntVar()
checkvar2 = IntVar()
checkvar3 = IntVar()

chkbtn1 = Checkbutton(raiz, text = "C",      variable = checkvar1, onvalue = 1, offvalue = 0, height = 2, width = 10, justify="right")
chkbtn2 = Checkbutton(raiz, text = "C++",    variable = checkvar2, onvalue = 1, offvalue = 0, height = 2, width = 10, justify="right")
chkbtn3 = Checkbutton(raiz, text = "Python", variable = checkvar3, onvalue = 1, offvalue = 0, height = 2, width = 10, justify="right")

chkbtn1.pack()
chkbtn2.pack()
chkbtn3.pack()
chkbtn3.select()


raiz.mainloop()


