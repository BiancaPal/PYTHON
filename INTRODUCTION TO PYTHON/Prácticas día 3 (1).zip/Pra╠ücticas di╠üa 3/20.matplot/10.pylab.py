# 10.pylab.py
# juanfc 2019-10-22
https://pythonspot.com/matplotlib-pie-chart/

from pylab import *

x = linspace(-3, 3, 30)
y = x**2

plot(x, y)

show()



