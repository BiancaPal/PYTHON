# 00.sin.py
# juanfc 2019-10-15

import matplotlib.pyplot as plt
import numpy as np
from numpy import pi

x = np.arange(0.0, 5.0, 0.02)
plt.plot(x, np.sin(2*pi*x), 'r--')
plt.plot(x, np.cos(2*pi*x), 'g--')
plt.plot(x, np.tan(2*pi*x), 'b--')
plt.show()
