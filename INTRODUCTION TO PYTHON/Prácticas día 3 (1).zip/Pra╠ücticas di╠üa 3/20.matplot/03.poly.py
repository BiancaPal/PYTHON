# 03.poly.py
# juanfc 2019-10-15

import matplotlib.pyplot as plt
import numpy as np

x = np.arange(0.0, 50.0, 0.02)
plt.plot(x, 3*x**5-5*x**3+2*x-7, 'r')
plt.show()
