# 10.symbols.py
# juanfc 2019-11-27
# https://alexandrugris.github.io/maths/2017/04/30/symbolic-maths-python.html
# https://docs.sympy.org/latest/tutorial/printing.html

from sympy import Symbol, symbols

X = Symbol('X')
expression = X + X + 1
print(expression)

a, b, c = symbols('a, b, c')
expression = a*b + b*a + a*c + c*a
print(expression)
