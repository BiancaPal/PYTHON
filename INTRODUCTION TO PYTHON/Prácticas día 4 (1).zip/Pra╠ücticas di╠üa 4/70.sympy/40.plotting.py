# 40.plotting.py
# juanfc 2019-11-27
from sympy.plotting import plot
import sympy as sp

x = sp.Symbol('x')
p = sp.plot(x**2, 3*x+1, x**2 * sp.sin(x), legend=True, show=False)
p[0].line_color = 'b'
p[1].line_color = 'r'
p.show()


