# 25.input.py
# juanfc 2019-11-27
from sympy import init_session
init_session()

expr1 = input("Input first expression")
expr2 = input("Input second expression")

try:
    expr1 = sympify(expr1)
    expr2 = sympify(expr2)

    print(expand(expr1 * expr2))

except SympifyError:
    print("Invalid input")



