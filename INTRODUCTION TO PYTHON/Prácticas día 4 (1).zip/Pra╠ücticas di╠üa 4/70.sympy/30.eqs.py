# 30.eqs.py
# juanfc 2019-11-27
import sympy as sp
x, y, z = sp.symbols('x y z')

### solving a quadratic equation:
q = x**2 - 2*x + 7
sp.solve(q)

# solving fpr one variable in terms of the other
q = x ** 2 + y * x + z
results = sp.solve(q, x)

# computing the results for a pair of y=2 and z=7 (same expression as above)
print([ret.subs({y: 2, z: 7}) for ret in results])


x, y, z = sp.symbols('x y z')
eq = sp.sin(x) + y * z
print(sp.solve(eq, x))
