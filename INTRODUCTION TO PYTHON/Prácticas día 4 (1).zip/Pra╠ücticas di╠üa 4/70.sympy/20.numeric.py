# 20.numeric.py
# juanfc 2019-11-27

import sympy as sp
from sympy import init_session
init_session()
expr = x**2 + 2*x*y + y**2
pprint(expr.subs({x:1, y:2}))
