# 20.links.py
# juanfc 2019-11-28

import httplib2
from bs4 import BeautifulSoup, SoupStrainer

http = httplib2.Http()
status, response = http.request('http://www.nytimes.com')

for link in BeautifulSoup(response, 'html.parser', parse_only=SoupStrainer('a')):
    if link.has_attr('href'):
        print(link['href'])

# status, response = http.request('http://www.uma.es')

# for link in BeautifulSoup(response, 'html.parser', parse_only=SoupStrainer('a')):
#     if link.has_attr('href'):
#         print(link['href'])



